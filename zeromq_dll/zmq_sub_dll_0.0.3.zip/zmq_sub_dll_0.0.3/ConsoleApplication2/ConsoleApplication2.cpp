// ConsoleApplication2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include <string>
#include <sstream>
#include <iostream>

using namespace std;

string message{"Hello "};
int msg_numb{ 0 };

int main()
{
	std::stringstream ss;
	ss << message << ++msg_numb;
	cout << ss.str() << endl;
    return 0;
}

